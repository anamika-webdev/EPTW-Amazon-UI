// frontend/src/pages/auth/SignupPage.tsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const SignupPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    full_name: '',
    password: '',
    confirmPassword: '',
    role: 'Requester',
    department: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({
    email: '',
    full_name: '',
    password: '',
    confirmPassword: ''
  });

  const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

  // Generate login_id from email (part before @)
  const generateLoginId = (email: string): string => {
    return email.split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, '_');
  };

  // Validate individual fields
  const validateField = (name: string, value: string) => {
    let errorMessage = '';

    switch (name) {
      case 'email':
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
          errorMessage = 'Invalid email format';
        }
        break;
      case 'full_name':
        if (value.length < 2) {
          errorMessage = 'Full name must be at least 2 characters';
        }
        break;
      case 'password':
        if (value.length < 8) {
          errorMessage = 'Password must be at least 8 characters';
        } else if (!/(?=.*[a-z])/.test(value)) {
          errorMessage = 'Password must contain lowercase letter';
        } else if (!/(?=.*[A-Z])/.test(value)) {
          errorMessage = 'Password must contain uppercase letter';
        } else if (!/(?=.*\d)/.test(value)) {
          errorMessage = 'Password must contain a number';
        } else if (!/(?=.*[@$!%*?&])/.test(value)) {
          errorMessage = 'Password must contain special character (@$!%*?&)';
        }
        break;
      case 'confirmPassword':
        if (value !== formData.password) {
          errorMessage = 'Passwords do not match';
        }
        break;
    }

    setValidationErrors(prev => ({ ...prev, [name]: errorMessage }));
    return errorMessage === '';
  };

  // Handle input change
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear general error when user types
    if (error) {
      setError('');
    }
    
    // Clear field-specific error when user starts typing
    if (validationErrors[name as keyof typeof validationErrors]) {
      validateField(name, value);
    }
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validate all fields
    const isEmailValid = validateField('email', formData.email);
    const isFullNameValid = validateField('full_name', formData.full_name);
    const isPasswordValid = validateField('password', formData.password);
    const isConfirmPasswordValid = validateField('confirmPassword', formData.confirmPassword);

    if (!isEmailValid || !isFullNameValid || !isPasswordValid || !isConfirmPasswordValid) {
      setError('Please fix all validation errors');
      setLoading(false);
      return;
    }

    try {
      // Generate login_id from email
      const login_id = generateLoginId(formData.email);

      console.log('Submitting registration:', {
        login_id,
        email: formData.email,
        full_name: formData.full_name,
        role: formData.role,
        department: formData.department || null
      });

      const response = await axios.post(`${API_BASE_URL}/auth/register`, {
        login_id: login_id,
        full_name: formData.full_name,
        email: formData.email,
        password: formData.password,
        role: formData.role,
        department: formData.department || null
      }, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 10000
      });

      console.log('Registration response:', response.data);

      if (response.data.success) {
        const { user } = response.data.data;
        
        console.log('Registration successful:', {
          login_id: user.login_id,
          email: user.email,
          role: user.role
        });
        
        // Show success message and redirect to login
        alert(`Account created successfully!\n\nYour Login ID: ${user.login_id}\n\nPlease use this Login ID to sign in.`);
        
        // Redirect to login page
        navigate('/login');
      } else {
        setError(response.data.message || 'Registration failed. Please try again.');
      }
    } catch (err: any) {
      console.error('Registration error:', err);
      
      if (err.code === 'ECONNABORTED') {
        setError('Request timeout. Please check your connection and try again.');
      } else if (err.response) {
        const errorMessage = err.response.data?.message || 'Registration failed';
        const statusCode = err.response.status;
        
        console.error('Server error:', {
          status: statusCode,
          message: errorMessage,
          data: err.response.data
        });
        
        if (statusCode === 409) {
          setError('An account with this email already exists. Please use a different email or try logging in.');
        } else if (statusCode === 400) {
          setError(errorMessage || 'Please check all required fields and try again.');
        } else if (statusCode === 500) {
          setError('Server error. Please try again later or contact support.');
        } else {
          setError(errorMessage);
        }
      } else if (err.request) {
        console.error('No response from server:', err.request);
        setError('Cannot connect to server. Please check if the backend is running on http://localhost:5000');
      } else {
        console.error('Request error:', err.message);
        setError('An unexpected error occurred. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen px-4 py-12 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center mb-6">
            <div className="flex items-center justify-center w-20 h-20 shadow-lg bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl">
              <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
              </svg>
            </div>
          </div>
          <h2 className="text-4xl font-bold tracking-tight text-gray-900">
            Create Your Account
          </h2>
          <p className="mt-3 text-base text-gray-600">
            Join the Amazon EPTW System
          </p>
        </div>

        {/* Signup Form */}
        <div className="p-8 bg-white shadow-xl rounded-2xl">
          <form className="space-y-5" onSubmit={handleSubmit}>
            {/* Email */}
            <div>
              <label htmlFor="email" className="block mb-2 text-sm font-semibold text-gray-700">
                Email Address *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  onBlur={(e) => validateField('email', e.target.value)}
                  className={`block w-full pl-12 pr-4 py-3.5 text-gray-900 placeholder-gray-400 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 sm:text-sm ${
                    validationErrors.email
                      ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                      : 'border-gray-300 focus:ring-blue-500 focus:border-transparent'
                  }`}
                  placeholder="Enter your email address"
                  autoComplete="email"
                />
              </div>
              {validationErrors.email && (
                <p className="mt-1.5 text-xs text-red-600 font-medium">{validationErrors.email}</p>
              )}
              {formData.email && !validationErrors.email && (
                <p className="mt-1.5 text-xs text-gray-600">
                  Your Login ID will be: <span className="font-semibold text-blue-600">{generateLoginId(formData.email)}</span>
                </p>
              )}
            </div>

            {/* Full Name */}
            <div>
              <label htmlFor="full_name" className="block mb-2 text-sm font-semibold text-gray-700">
                Full Name *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <input
                  id="full_name"
                  name="full_name"
                  type="text"
                  required
                  value={formData.full_name}
                  onChange={handleChange}
                  onBlur={(e) => validateField('full_name', e.target.value)}
                  className={`block w-full pl-12 pr-4 py-3.5 text-gray-900 placeholder-gray-400 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 sm:text-sm ${
                    validationErrors.full_name
                      ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                      : 'border-gray-300 focus:ring-blue-500 focus:border-transparent'
                  }`}
                  placeholder="Enter your full name"
                  autoComplete="name"
                />
              </div>
              {validationErrors.full_name && (
                <p className="mt-1.5 text-xs text-red-600 font-medium">{validationErrors.full_name}</p>
              )}
            </div>

            {/* Role Selection */}
            <div>
              <label htmlFor="role" className="block mb-2 text-sm font-semibold text-gray-700">
                Role *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <select
                  id="role"
                  name="role"
                  required
                  value={formData.role}
                  onChange={handleChange}
                  className="block w-full pl-12 pr-4 py-3.5 text-gray-900 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 sm:text-sm appearance-none"
                >
                  <option value="Requester">Requester (Worker)</option>
                  <option value="Approver_Safety">Safety Officer</option>
                  <option value="Approver_AreaManager">Area Manager</option>
                  <option value="Admin">Administrator</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Department (Optional) */}
            <div>
              <label htmlFor="department" className="block mb-2 text-sm font-semibold text-gray-700">
                Department <span className="text-xs font-normal text-gray-500">(Optional)</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                </div>
                <input
                  id="department"
                  name="department"
                  type="text"
                  value={formData.department}
                  onChange={handleChange}
                  className="block w-full pl-12 pr-4 py-3.5 text-gray-900 placeholder-gray-400 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 sm:text-sm"
                  placeholder="Enter your department"
                  autoComplete="organization"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block mb-2 text-sm font-semibold text-gray-700">
                Password *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  onBlur={(e) => validateField('password', e.target.value)}
                  className={`block w-full pl-12 pr-4 py-3.5 text-gray-900 placeholder-gray-400 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 sm:text-sm ${
                    validationErrors.password
                      ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                      : 'border-gray-300 focus:ring-blue-500 focus:border-transparent'
                  }`}
                  placeholder="Create a password"
                  autoComplete="new-password"
                />
              </div>
              {validationErrors.password && (
                <p className="mt-1.5 text-xs text-red-600 font-medium">{validationErrors.password}</p>
              )}
              <p className="mt-1.5 text-xs text-gray-500">
                Min 8 characters with uppercase, lowercase, number & special character
              </p>
            </div>

            {/* Confirm Password */}
            <div>
              <label htmlFor="confirmPassword" className="block mb-2 text-sm font-semibold text-gray-700">
                Confirm Password *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  required
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  onBlur={(e) => validateField('confirmPassword', e.target.value)}
                  className={`block w-full pl-12 pr-4 py-3.5 text-gray-900 placeholder-gray-400 border rounded-xl focus:outline-none focus:ring-2 transition-all duration-200 sm:text-sm ${
                    validationErrors.confirmPassword
                      ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                      : 'border-gray-300 focus:ring-blue-500 focus:border-transparent'
                  }`}
                  placeholder="Confirm your password"
                  autoComplete="new-password"
                />
              </div>
              {validationErrors.confirmPassword && (
                <p className="mt-1.5 text-xs text-red-600 font-medium">{validationErrors.confirmPassword}</p>
              )}
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-4 border border-red-200 rounded-xl bg-gradient-to-r from-red-50 to-red-100">
                <div className="flex">
                  <svg 
                    className="flex-shrink-0 w-5 h-5 text-red-500" 
                    viewBox="0 0 20 20" 
                    fill="currentColor"
                  >
                    <path 
                      fillRule="evenodd" 
                      d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" 
                      clipRule="evenodd" 
                    />
                  </svg>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-red-800">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="relative flex justify-center w-full px-4 py-3.5 text-sm font-semibold text-white transition-all duration-200 bg-gradient-to-r from-indigo-600 to-purple-600 border border-transparent rounded-xl hover:from-indigo-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                {loading ? (
                  <span className="flex items-center">
                    <svg className="w-5 h-5 mr-3 -ml-1 text-white animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Creating account...
                  </span>
                ) : (
                  'Create Account'
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Login Link */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Already have an account?{' '}
            <Link 
              to="/login" 
              className="font-semibold text-indigo-600 transition-colors hover:text-indigo-500"
            >
              Sign in here
            </Link>
          </p>
        </div>

        {/* Info Box */}
        <div className="p-4 mt-6 border border-indigo-200 rounded-xl bg-gradient-to-r from-indigo-50 to-purple-50">
          <div className="flex">
            <svg className="flex-shrink-0 w-5 h-5 text-indigo-500" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
            <div className="ml-3">
              <p className="text-xs font-medium text-indigo-800">
                After registration, you'll receive a Login ID. Use it to sign in to your account.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;